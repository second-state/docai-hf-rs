// SPDX-License-Identifier: CC0-1.0
#define CATCH_CONFIG_MAIN
#include "catch.hpp"
