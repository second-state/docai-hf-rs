# Build WasmEdge for Raspberry Pi 3/4

> This part has been moved to  <https://wasmedge.org/docs/contribute/source/os/raspberrypi>. Please use our new docs.
