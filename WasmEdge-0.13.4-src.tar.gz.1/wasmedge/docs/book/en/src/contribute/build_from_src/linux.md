# Build WasmEdge on Linux

> This part has been moved to  <https://wasmedge.org/docs/contribute/source/os/linux>. Please use our new docs.
