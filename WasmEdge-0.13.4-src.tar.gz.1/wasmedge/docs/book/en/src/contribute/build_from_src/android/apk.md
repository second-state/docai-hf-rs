# Call WasmEdge functions from an Android APK app

> This part has been moved to  <https://wasmedge.org/docs/contribute/source/os/android/apk>. Please use our new docs.
