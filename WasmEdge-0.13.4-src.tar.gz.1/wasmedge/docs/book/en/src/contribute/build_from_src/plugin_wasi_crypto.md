# Build WasmEdge With WASI-Crypto Plug-in

> This part has been moved to  <https://wasmedge.org/docs/contribute/source/plugin/wasi_crypto>. Please use our new docs.
