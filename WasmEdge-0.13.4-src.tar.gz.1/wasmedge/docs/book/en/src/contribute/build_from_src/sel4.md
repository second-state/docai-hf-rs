# Build WasmEdge for seL4

This part hs moved to <https://wasmedge.org/docs/contribute/source/os/sel4>. Please use our new docs.
