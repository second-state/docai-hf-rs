# Execution in AOT Mode

> This part has been moved to <https://wasmedge.org/docs/start/build-and-run/aot>. Please use our new docs.
