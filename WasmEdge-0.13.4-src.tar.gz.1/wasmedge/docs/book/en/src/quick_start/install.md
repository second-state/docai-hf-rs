# WasmEdge Installation And Uninstallation

> This part has been moved to <https://wasmedge.org/docs/start/install>. Please use our new docs.