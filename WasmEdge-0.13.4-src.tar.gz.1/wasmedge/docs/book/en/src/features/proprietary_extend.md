# WasmEdge Proprietary Extensions

> This part has been moved to <https://wasmedge.org/docs/develop/wasmedge/extensions/unique_extensions>. Please use our new docs.
