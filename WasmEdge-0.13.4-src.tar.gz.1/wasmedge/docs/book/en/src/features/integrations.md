# WasmEdge Integrations

> This part has been moved to <https://wasmedge.org/docs/start/wasmedge/integrations>. Please use our new docs.
