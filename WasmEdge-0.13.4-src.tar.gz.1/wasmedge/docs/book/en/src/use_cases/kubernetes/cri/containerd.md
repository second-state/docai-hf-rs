# containerd

This docs has moved to <https://wasmedge.org/docs/develop/deploy/cri-runtime/containerd-crun>. Please use our new docs.
