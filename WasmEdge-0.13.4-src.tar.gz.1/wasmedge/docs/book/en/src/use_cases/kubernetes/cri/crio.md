# CRI-O

This docs has moved to <https://wasmedge.org/docs/develop/deploy/cri-runtime/cri-o-crun>. Please use our new docs.
