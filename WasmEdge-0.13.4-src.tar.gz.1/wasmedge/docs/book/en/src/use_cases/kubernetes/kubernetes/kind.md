# Kubernetes in Docker (KinD)

> This part has been moved to  <https://wasmedge.org/docs/develop/deploy/kubernetes/kind>. Please use our new docs.
