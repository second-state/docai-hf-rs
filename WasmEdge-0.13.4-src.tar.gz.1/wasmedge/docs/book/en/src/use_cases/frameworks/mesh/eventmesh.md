# Apache EventMesh

Coming soon, or you can [help out](https://github.com/WasmEdge/WasmEdge/issues/632)
